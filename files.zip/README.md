# The House of PHZE

A modern, MySpace-inspired artist profile for PHZE.

- **Edit content easily:** See `HOW-TO-UPDATE-CONTENT.md`
- **Host for free:** See `HOW-TO-HOST.md`